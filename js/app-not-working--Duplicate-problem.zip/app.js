let spendedArray = [];
let namesArray = [];

// check if there is any Expense in LocalStorage, if true changes display of #chart
chartD();
function chartD() {
  if (localStorage.getItem("ChartDisplay")) {
    if (localStorage.getItem("ChartDisplay") == "hide") {
      showHide(1);
    } else {
      showHide(0);
    }
  } else {
    showHide(0);
  }
}

//chControl();
function chControl() {
  let show = Number;
  let marginRight = document.querySelector("#chartcontrol > img").getAttribute("style");
  let dataID = document.querySelector("#chartcontrol > img").getAttribute("data-id");

  if (dataID == 0 || marginRight == "margin-right: 2.20em;") {
    // when show is true that means its showing the chart
    show = 0;
    console.log(show);
    showHide(show);
    localStorage.setItem("ChartDisplay", "show");
  } else {
    show = 1;
    console.log(show);
    showHide(show);
    localStorage.setItem("ChartDisplay", "hide");
  }
}

function showHide(dataID) {
  let bothLength;
  let show = Number;
  if (localStorage.getItem("Both")) {
    bothLength = JSON.parse(localStorage.getItem("Both")).expenseAmount.length;
  } else {
    bothLength = 0;
  }
  if (dataID == 0) {
    console.log(dataID);
    document.querySelector("#chartcontrol > img").style = "";
    document.querySelector("#chart").style = "display: block";
    document.querySelector("#width").style = "";
    document.querySelector("#chartcontrol > img").setAttribute("data-id", 1);
    if (bothLength > 0) {
      chart();
    } else {
      document.querySelector("#chart").style = "display: none";
      document.querySelector("#width").style = "max-width: 66% !important";
    }
  } else {
    console.log(dataID);
    document.querySelector("#chartcontrol > img").style = "margin-right: 2.20em;";
    document.querySelector("#chart").style = "display: none";
    document.querySelector("#width").style = "max-width: 66% !important";
    document.querySelector("#chartcontrol > img").setAttribute("data-id", 0);
  }
}

// Class
class Budget {
  constructor(budget) {
    this.budget = Number(budget);
    this.budgetLeft = Number(this.budget);
    console.log(budget);
    console.log(this.budget);
  }

  subtractFromBudget(spended) {
    console.log(spended);
    let newBudget = (this.budgetLeft -= spended);
    console.log(newBudget);
    return Number(newBudget);
  }
}
let newspendedArray = []
let newnamesArray = []
// Everything related to HTML
class HTML {
  insertBudget(amountOfBudget) {
    budgetAmount.innerHTML =
      "بودجه شما برابر است با: " +
      Number(amountOfBudget).toLocaleString() +
      " تومان";
    budgetTotal.innerHTML = Number(amountOfBudget).toLocaleString();
    document.querySelector("input[name=budget]").value = Number(amountOfBudget);
  }
  insertExpense(spended, expenseName) {
    let dataId = document.querySelectorAll("#expenses span.badge").length;
    const expenses = document.querySelector("#expenses ul");
    let li = document.createElement("li");
    li.classList =
      "list-group-item f-flex justify-content-between align-items-center";
    li.setAttribute("data-id", dataId);
    li.innerHTML = `
    <span class='amount'>${Number(spended).toLocaleString()}</span>
    <span class='badge badge-pill badge-primary'>${expenseName}</span>
    <span class='remove'>X</span>
    `;
    spendedArray.push(Number(spended));
    namesArray.push(expenseName);
    let expenseList = {
      expenseName: namesArray,
      expenseAmount: spendedArray,
    };
    console.log(expenseList);
    localStorage.setItem("Both", JSON.stringify(expenseList));
    expenses.appendChild(li);
  }

  
  // insert Expenses WithOut Saving to LS
  insertExpenseWithOutSave(spended, expenseName) {
    let dataId = document.querySelectorAll("#expenses span.badge").length;
    const expenses = document.querySelector("#expenses ul");
    let li = document.createElement("li");
    li.classList =
      "list-group-item f-flex justify-content-between align-items-center";
    li.setAttribute("data-id", dataId);
    li.innerHTML = `
    <span class='amount'>${Number(spended).toLocaleString()}</span>
    <span class='badge badge-pill badge-primary'>${expenseName}</span>
    <span class='remove'>X</span>
    `;

    newspendedArray.push(Number(spended));
    newnamesArray.push(expenseName);
    let expenseList = {
      expenseName: newnamesArray,
      expenseAmount: newspendedArray,
    };
    console.log(expenseList);
      localStorage.setItem("Both", JSON.stringify(expenseList));
    
    expenses.appendChild(li);
  }

  trackBudget(spended) {
    let bLeft = userBudget.subtractFromBudget(spended);
    console.log(bLeft);
    budgetLeft.innerHTML = `${Number(bLeft).toLocaleString()}`;
  }

  printMessage(message, className) {
    const div = document.createElement("div");
    div.classList.add("alert", "text-center", className);
    div.appendChild(document.createTextNode(message));
    budgetAmount.appendChild(div);

    setTimeout(() => {
      document.querySelector(".alert").remove();
      form.reset();
    }, 3500);
  }
}

// Variables
let budgetEntry = document.querySelector(".amout input");
let budgetAmount = document.querySelector(".budgetamount");
let budgetTotal = document.querySelector("#total");
let budgetLeft = document.querySelector("#left");
let amount = document.querySelector("#amount");
const form = document.querySelector("#add-expense");
let expenseN = document.querySelector("#expense");
let expenses = document.querySelector("#expenses");
const chartControl = document.querySelector("#chartcontrol");
const reset = document.querySelector("#reset");
let userBudget;

const html = new HTML();

// Eventlisteners

chartControl.addEventListener("click", chControl);
reset.addEventListener("click", resetFunction);

budgetEntry.addEventListener("blur", function () {
  userBudget = budgetEntry.value;
  userBudget = new Budget(userBudget);
  console.log(userBudget);
  html.insertBudget(userBudget.budget);
  updateBudget();
});

budgetEntry.addEventListener("keypress", function (e) {
  if (e.key === "Enter") {
    userBudget = budgetEntry.value;
    userBudget = new Budget(userBudget);
    html.insertBudget(userBudget.budget);
    updateBudget();
  }
});

setTimeout(() => {
  expenses.addEventListener("click", function (e) {
    console.log(e.target);
    if (e.target.classList.contains("remove")) {
      console.log("its contains remove");
      console.log(e.target.parentElement.querySelector(".badge").textContent);
      let both = localStorage.getItem("Both");
      both = JSON.parse(both);
      console.log(both.expenseName.length);
      console.log(both);
      let dataId = e.target.parentElement.getAttribute("data-id");
      console.log(both.expenseName[dataId]);
      // e.target.parentElement.remove()
      console.log(e.target.parentElement.querySelector(".badge").textContent);
      //for (let i = 0; i < both.expenseName.length; i++) {
      if (e.target.parentElement.querySelector(".badge").textContent === both.expenseName[dataId]) {
        let leftBudget = localStorage.getItem("Left");
        let newtBudget = leftBudget - both.expenseAmount[dataId];
        console.log(both.expenseAmount[dataId]);
        console.log(newtBudget);
        localStorage.setItem("Left", newtBudget);

        both.expenseName.splice(dataId, 1);
        both.expenseAmount.splice(dataId, 1);

        console.log(both.expenseName);
        console.log(both.expenseAmount);
        console.log(both);
        localStorage.setItem("Both", JSON.stringify(both));
        e.target.parentElement.remove();
        document.querySelectorAll("#expenses > ul > li").forEach((x) => x.remove());
        updateAll();
        insertFunctionForW();
        chart();
      }
      //}
    }
    console.log(expenses);
  });
}, 2000);

form.addEventListener("submit", expense);

function expense(e) {
  e.preventDefault();
  userBudget = budgetEntry.value;
  userBudget = new Budget(userBudget);
  curentBudget = userBudget.budget;
  console.log(curentBudget);
  let spended = amount.value;
  let expenseName = expenseN.value;
  let newBudget = curentBudget - spended;
  if (spended == "" || spended == 0) {
    html.printMessage("خطا! لطفا همه موارد را وارد کنید.", "alert-danger");
  } else {
    html.insertExpenseWithOutSave(spended, expenseName);
    html.trackBudget(spended);
    let oldCurentBudget = localStorage.getItem("Budget");
    let newCurentBudget = localStorage.getItem("Both");
    newCurentBudget = JSON.parse(newCurentBudget);
    console.log(newCurentBudget);
    console.log(newCurentBudget.expenseAmount);
    console.log(oldCurentBudget);
    for (let i = 0; i < newCurentBudget.expenseAmount.length; i++) {
      console.log(newCurentBudget.expenseAmount[i]);
      oldCurentBudget -= newCurentBudget.expenseAmount[i];
    }
    console.log(oldCurentBudget);
    budgetLeft.innerHTML = `${Number(oldCurentBudget).toLocaleString()}`;

    localStorage.setItem("Budget", userBudget.budget);
    chart();
    chartD();
  }

  console.log(curentBudget);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// if (localStorage.getItem("Both")) {
//   ls = localStorage.getItem("Both");
//   ls = JSON.parse(ls);
//   let lsBudget = localStorage.getItem("Budget");
//   let newBud = new Budget(lsBudget);
//   for (let i = 0; i < ls.expenseAmount.length; i++) {
//     let update = newBud.subtractFromBudget(ls.expenseAmount[i]);
//     localStorage.setItem("Left", Number(update));
//     budgetLeft.innerHTML = `${Number(update).toLocaleString()}`;
//   }
// }

// send to html.insertBudget function
//insertFunction();
function insertFunction() {
  if (localStorage.getItem("Budget") && localStorage.getItem("Both")) {
    ls = localStorage.getItem("Both");
    console.log(ls);
    console.log(JSON.parse(ls));
    ls = JSON.parse(ls);
    console.log(ls.expenseName);

    lsBudget = localStorage.getItem("Budget");
    html.insertBudget(lsBudget);

    console.log(typeof ls);
    let newBud = new Budget(lsBudget);
    for (let i = 0; i < ls.expenseAmount.length; i++) {
      html.insertExpense(ls.expenseAmount[i], ls.expenseName[i]);
      console.log(ls.expenseAmount[i]);
      let update = newBud.subtractFromBudget(ls.expenseAmount[i]);
      localStorage.setItem("Left", Number(update));
      budgetLeft.innerHTML = `${Number(update).toLocaleString()}`;
    }
  }
}

// send to html.insertBudgetWithoutSave function
insertFunctionForW()
function insertFunctionForW() {
  if (localStorage.getItem("Budget") && localStorage.getItem("Both")) {
    ls = localStorage.getItem("Both");
    ls = JSON.parse(ls);
    lsBudget = localStorage.getItem("Budget");
    html.insertBudget(lsBudget);
    console.log(typeof ls);
    let newBud = new Budget(lsBudget);
    for (let i = 0; i < ls.expenseAmount.length; i++) {
      html.insertExpenseWithOutSave(ls.expenseAmount[i], ls.expenseName[i]);
      let update = newBud.subtractFromBudget(ls.expenseAmount[i]);
      localStorage.setItem("Left", Number(update));
      budgetLeft.innerHTML = `${Number(update).toLocaleString()}`;
    }
  }
}
function updateBudget() {
  let curentBudget = localStorage.getItem("Budget");
  let newCurentBudget = document.querySelector("input[name=budget]").value;
  if (newCurentBudget !== curentBudget) {
    localStorage.setItem("Budget", newCurentBudget);
    updateAll();
  }
}

function updateAll() {
  let curentBudget = localStorage.getItem("Budget");
  console.log(curentBudget);
  let newCurentBudget = document.querySelector("input[name=budget]").value;
  if (localStorage.getItem("Both")) {
    let both = localStorage.getItem("Both");
    both = JSON.parse(both);
    let allExpenses = 0;
    for (let i = 0; i < both.expenseAmount.length; i++) {
      allExpenses += Number(both.expenseAmount[i]);
    }
    let finalBudget = curentBudget - allExpenses;
    console.log(both.expenseAmount[0]);
    console.log(allExpenses);
    console.log(finalBudget);
    budgetLeft.innerHTML = Number(finalBudget).toLocaleString();
    localStorage.setItem("Left", finalBudget);
  }
}

function chart() {
  google.charts.load("current", { packages: ["corechart"] });
  google.charts.setOnLoadCallback(drawChart);
  ls = localStorage.getItem("Both");
  ls = JSON.parse(ls);
  let newArray = [];
  console.log(newArray instanceof Array);
  newArray.push(["Expenses", "Expense Amount"]);
  for (let i = 0; i < ls.expenseAmount.length; i++) {
    newArray.push([`${ls.expenseName[i]}`, ls.expenseAmount[i]]);
  }

  console.log(typeof newArray);
  console.log(newArray);
  console.log(newArray[0] + " " + newArray[1]);
  console.log(newArray[0]);
  console.log(typeof newArray[0]);

  let newArraySecond = [];
  newArraySecond.push(newArray);
  console.log(newArraySecond);

  function drawChart() {
    for (let i = 0; i < newArraySecond.length; i++) {
      var data = google.visualization.arrayToDataTable(newArraySecond[i]);

      console.log(newArray[i]);
    }

    var options = {
      title: "چارت هزینه ها",
      titleTextStyle: {
        bold: false,
        fontSize: 23,
        alignment: "none",
      },
      is3D: true,
      height: 330,
      width: 500,
      fontSize: 17,
      fontName: "vazir-medium",
      backgroundColor: {
        fill: "transparent",
      },
    };

    var chart = new google.visualization.PieChart(
      document.getElementById("piechart_3d")
    );
    chart.draw(data, options);
  }
}
//chart()



function resetFunction(){
 let conf = confirm("آیا از حذف همه ی داده ها اطمینان دارید؟")
  if (conf == true) {
    reset.style = 'transform: scale(1.5);'
    document.querySelector('#reset > img').style = 'transition: 3s;transform: rotate(360deg);'

    setTimeout(() => {
    reset.style = ''
    document.querySelector('#reset > img').style = ''
    }, 3000);
    setTimeout(() => {
        localStorage.clear()
    }, 4000);
    setTimeout(() => {
        window.location.reload()
    }, 4500);

}
}