let spendedArray = [];
let namesArray = []
// Class
class Budget {
  constructor(budget) {
    this.budget = Number(budget); //.toLocaleString()
    this.budgetLeft = Number(this.budget); //.toLocaleString()
    console.log(budget);
    console.log(this.budget);
  }

  subtractFromBudget(spended){
    console.log(spended);
    let newBudget = this.budgetLeft -= spended
    console.log(newBudget);
    return Number(newBudget);
  }
}

// Everything related to HTML
class HTML {
  insertBudget(amountOfBudget) {
    budgetAmount.innerHTML =
      "بودجه شما برابر است با: " + amountOfBudget.toLocaleString() + " تومان";
    budgetTotal.innerHTML = amountOfBudget.toLocaleString();
    document.querySelector("input[name=budget]").value = amountOfBudget.toLocaleString();
  }
  insertExpence(spended, expenseName){
    const expenses = document.querySelector("#expenses ul");
    let li = document.createElement('li')
    li.classList = 'list-group-item f-flex justify-content-between align-items-center'
    li.innerHTML = `
    ${Number(spended).toLocaleString()}
    <span class='badge badge-pill badge-primary'> ${expenseName}</span>
    `
    spendedArray.push(Number(spended))
    namesArray.push(expenseName)
    let expenseList = {
      expenseName: namesArray,
      expenseAmount: spendedArray
    }
    console.log(expenseList)
    localStorage.setItem('Expences',expenseList.expenseName)
    localStorage.setItem('Amount', expenseList.expenseAmount)
    localStorage.setItem('Both', JSON.stringify(expenseList))
    expenses.appendChild(li)
    let allExpenses = ''
   // console.log(allExpenses);
// let result = userBudget.budget - allExpenses
   // budgetLeft.innerHTML =  userBudget.budget - spended//.toLocaleString();
  }

  trackBudget(spended){
        let bLeft = userBudget.subtractFromBudget(spended)
        console.log(bLeft)
         budgetLeft.innerHTML = `${Number(bLeft).toLocaleString()}`
  }

  printMessage(message, className) {
    const div = document.createElement("div");
    div.classList.add("alert", "text-center", className);
    div.appendChild(document.createTextNode(message));
    budgetAmount.appendChild(div);

    setTimeout(() => {
      document.querySelector(".alert").remove();
      form.reset();
    }, 3500);
  }
}

// Variables
let budgetEntry = document.querySelector(".amout input");
let budgetAmount = document.querySelector(".budgetamount");
let budgetTotal = document.querySelector("#total");
let budgetLeft = document.querySelector("#left");
let amount = document.querySelector("#amount");
const form = document.querySelector("#add-expense");
let expenseN = document.querySelector("#expense");
let userBudget;
//let budget = new Budget;
let userBudgetString;

const html = new HTML();

// Eventlisteners
budgetEntry.addEventListener("blur", function () {
  userBudget = budgetEntry.value;
  //userBudgetString = Number(userBudget).toLocaleString()
  userBudget = new Budget(userBudget);
  console.log(userBudget);
  html.insertBudget(userBudget.budget);
  updateAll()
});

budgetEntry.addEventListener("keypress", function (e) {
  if (e.key === "Enter") {
    userBudget = budgetEntry.value;
    // userBudgetString = Number(userBudget).toLocaleString()
    // budgetAmount.innerHTML = 'بودجه شما برابر است با: ' + userBudgetString + ' تومان'
    // console.log(userBudgetString)
    userBudget = new Budget(userBudget);
    html.insertBudget(userBudget.budget);
    updateAll()
  }
});

form.addEventListener("submit", expense);

function expense(e) {
  e.preventDefault();
  curentBudget = userBudget.budget;
  //curentBudget = curentBudget.replace(',' , '')
  console.log(curentBudget);
  let spended = amount.value;
  let expenseName = expenseN.value;
  let newBudget = curentBudget - spended;
  if (spended == "" || spended == 0) {
    html.printMessage("خطا! لطفا همه موارد را وارد کنید.", "alert-danger");
  } else {
   // budget = new Budget(curentBudget)
    html.insertExpence(spended, expenseName);
    html.trackBudget(spended);
    localStorage.setItem('Budget', userBudget.budget)
  }

  console.log(curentBudget);
}

if (localStorage.getItem('Budget') && localStorage.getItem('Amount') && localStorage.getItem('Expences')){
  // let lsAmount = localStorage.getItem('Amount');
  // lsAmount = JSON.parse("[" + lsAmount + "]")

  // let lsName = localStorage.getItem('Expences');
 // ls = JSON.parse(localStorage.getItem('Both'))
  ls = localStorage.getItem('Both')
 // ls = JSON.parse("[" + ls + "]")
   console.log(ls);
   console.log(JSON.parse(ls));
   ls = JSON.parse(ls)
   console.log(ls.expenseName);

 // console.log(JSON.stringify(ls));
  lsBudget = localStorage.getItem('Budget')
  html.insertBudget(lsBudget);



  //console.log(JSON.parse("[" + ls + "]"));
  console.log(typeof ls);
  let newBud = new Budget(lsBudget);
  for (let i = 0; i < ls.expenseAmount.length; i++) {
    //let element = ls.expenseAmount[i];
    html.insertExpence(ls.expenseAmount[i], ls.expenseName[i])
    console.log(ls.expenseAmount[i]);
      //html.trackBudget(ls.expenseAmount[i]);
     // html.trackBudget(ls.expenseAmount[i]);
      
    let update = newBud.subtractFromBudget(ls.expenseAmount[i])
    budgetLeft.innerHTML = `${Number(update).toLocaleString()}`
      //html.trackBudget(ls.expenseAmount[i])
  }
  
}

function updateAll(){
  let curentBudget = localStorage.getItem('Budget')
  console.log(curentBudget)
  let newCurentBudget = document.querySelector("input[name=budget]").value;
  let difference = newCurentBudget - curentBudget
  console.log(budgetLeft.textContent)
  budgetLeft.innerHTML =  Number(budgetLeft.textContent) + difference
  let spended = amount.value;
  let expenseName = expenseN.value;
  localStorage.setItem('Budget', newCurentBudget)
  console.log(newCurentBudget + ' its from updateAll function')
}